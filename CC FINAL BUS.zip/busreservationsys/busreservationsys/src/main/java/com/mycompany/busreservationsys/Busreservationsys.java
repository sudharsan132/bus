/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.busreservationsys;

/**
 *
 * @author SaMsEn
 */
public class Busreservationsys {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
